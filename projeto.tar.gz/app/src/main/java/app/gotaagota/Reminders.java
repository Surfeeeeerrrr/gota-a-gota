package app.gotaagota;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.AudioAttributes;
import android.media.RingtoneManager;
import android.os.Build;

import java.util.Calendar;

/** Agenda e mostra os lembretes de água, mesmo com o app fechado ou o celular bloqueado. */
public final class Reminders {

    static final String PREFS = "gota_lembretes";
    static final String CHANNEL = "lembretes_agua";
    static final String ACTION_FIRE = "app.gotaagota.FIRE";
    static final String ACTION_SNOOZE = "app.gotaagota.SNOOZE";
    static final int NOTIF_ID = 42;

    private Reminders() {}

    static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    static void save(Context c, boolean on, int every, int start, int end) {
        prefs(c).edit()
                .putBoolean("on", on)
                .putInt("every", Math.max(15, every))
                .putInt("start", start)
                .putInt("end", end)
                .apply();
    }

    /** Próximo horário da grade: começa na hora inicial e repete a cada N minutos até a hora final. */
    static long nextSlot(Context c, long from) {
        SharedPreferences p = prefs(c);
        int every = p.getInt("every", 60);
        int start = p.getInt("start", 8);
        int end = p.getInt("end", 22);
        for (int day = 0; day < 2; day++) {
            Calendar base = Calendar.getInstance();
            base.setTimeInMillis(from);
            base.add(Calendar.DAY_OF_MONTH, day);
            base.set(Calendar.HOUR_OF_DAY, start);
            base.set(Calendar.MINUTE, 0);
            base.set(Calendar.SECOND, 0);
            base.set(Calendar.MILLISECOND, 0);
            Calendar last = (Calendar) base.clone();
            last.set(Calendar.HOUR_OF_DAY, end);
            for (long t = base.getTimeInMillis(); t <= last.getTimeInMillis(); t += every * 60000L) {
                if (t > from) return t;
            }
        }
        return -1;
    }

    private static PendingIntent firePending(Context c) {
        Intent i = new Intent(c, ReminderReceiver.class).setAction(ACTION_FIRE);
        return PendingIntent.getBroadcast(c, 1, i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    static void setAlarmAt(Context c, long when) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        PendingIntent pi = firePending(c);
        prefs(c).edit().putLong("next", when).apply();
        boolean exact = Build.VERSION.SDK_INT < Build.VERSION_CODES.S || am.canScheduleExactAlarms();
        if (exact) {
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, pi);
        } else {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, pi);
        }
    }

    /** Agenda o próximo lembrete, ou cancela se estiver desligado. */
    static void schedule(Context c) {
        if (!prefs(c).getBoolean("on", false)) {
            cancel(c);
            return;
        }
        long next = nextSlot(c, System.currentTimeMillis());
        if (next > 0) setAlarmAt(c, next);
    }

    static void snooze(Context c, int minutes) {
        setAlarmAt(c, System.currentTimeMillis() + minutes * 60000L);
    }

    static void cancel(Context c) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (am != null) am.cancel(firePending(c));
        prefs(c).edit().putLong("next", -1).apply();
    }

    static long nextTime(Context c) {
        return prefs(c).getBoolean("on", false) ? prefs(c).getLong("next", -1) : -1;
    }

    static void ensureChannel(Context c) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return;
        NotificationManager nm = c.getSystemService(NotificationManager.class);
        if (nm == null || nm.getNotificationChannel(CHANNEL) != null) return;
        NotificationChannel ch = new NotificationChannel(CHANNEL, "Lembretes de água",
                NotificationManager.IMPORTANCE_HIGH);
        ch.setDescription("Avisos para beber água ao longo do dia");
        ch.enableVibration(true);
        ch.setVibrationPattern(new long[]{0, 300, 150, 300, 150, 500});
        AudioAttributes aa = new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build();
        ch.setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION), aa);
        nm.createNotificationChannel(ch);
    }

    static void show(Context c, boolean test) {
        ensureChannel(c);
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;

        Intent open = new Intent(c, MainActivity.class)
                .setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent openPi = PendingIntent.getActivity(c, 10, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Intent drink = new Intent(c, MainActivity.class)
                .setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP)
                .putExtra("drink", true);
        PendingIntent drinkPi = PendingIntent.getActivity(c, 11, drink,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Intent later = new Intent(c, ReminderReceiver.class).setAction(ACTION_SNOOZE);
        PendingIntent laterPi = PendingIntent.getBroadcast(c, 12, later,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        String text = test ? "Assim vai aparecer o seu lembrete." : "Que tal o próximo copo?";

        Notification.Builder b = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? new Notification.Builder(c, CHANNEL)
                : new Notification.Builder(c);
        b.setSmallIcon(R.drawable.ic_drop)
                .setContentTitle("Hora da água!")
                .setContentText(text)
                .setColor(0xFF1D8EA4)
                .setAutoCancel(true)
                .setCategory(Notification.CATEGORY_REMINDER)
                .setContentIntent(openPi)
                .addAction(new Notification.Action.Builder(null, "Bebi um copo", drinkPi).build())
                .addAction(new Notification.Action.Builder(null, "Daqui a 10 min", laterPi).build());
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
            b.setPriority(Notification.PRIORITY_HIGH)
                    .setDefaults(Notification.DEFAULT_SOUND)
                    .setVibrate(new long[]{0, 300, 150, 300, 150, 500});
        }
        try {
            nm.notify(NOTIF_ID, b.build());
        } catch (SecurityException ignored) {
            // permissão de notificação negada
        }
    }

    static void dismiss(Context c) {
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null) nm.cancel(NOTIF_ID);
    }
}

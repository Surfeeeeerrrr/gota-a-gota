package app.gotaagota;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {

    private WebView web;
    private boolean loaded = false;
    private boolean pendingDrink = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Reminders.ensureChannel(this);

        web = new WebView(this);
        web.setBackgroundColor(Color.parseColor("#38B3C8"));
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setTextZoom(100);
        web.addJavascriptInterface(new Bridge(), "Android");
        web.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                loaded = true;
                if (pendingDrink) {
                    pendingDrink = false;
                    drinkInPage();
                }
            }
        });
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");

        Reminders.schedule(this);
        handleIntent(getIntent());
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleIntent(intent);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (loaded) web.evaluateJavascript("window.gotaResume&&window.gotaResume()", null);
    }

    private void handleIntent(Intent intent) {
        if (intent != null && intent.getBooleanExtra("drink", false)) {
            intent.removeExtra("drink");
            Reminders.dismiss(this);
            if (loaded) drinkInPage(); else pendingDrink = true;
        }
    }

    private void drinkInPage() {
        web.evaluateJavascript("window.gotaDrinkToday&&window.gotaDrinkToday()", null);
    }

    @Override
    public void onBackPressed() {
        web.evaluateJavascript("window.gotaBack?window.gotaBack():false", value -> {
            if (!"true".equals(value)) MainActivity.super.onBackPressed();
        });
    }

    private void askNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 7);
        }
    }

    /** Ponte entre a página e o Android. */
    class Bridge {
        @JavascriptInterface
        public void setReminders(boolean on, int every, int start, int end) {
            Reminders.save(MainActivity.this, on, every, start, end);
            Reminders.schedule(MainActivity.this);
            if (on) runOnUiThread(MainActivity.this::askNotificationPermission);
        }

        @JavascriptInterface
        public void setLastDrink(double ts) {
            Reminders.prefs(MainActivity.this).edit().putLong("lastDrink", (long) ts).apply();
        }

        @JavascriptInterface
        public void testReminder() {
            runOnUiThread(() -> {
                askNotificationPermission();
                Reminders.show(MainActivity.this, true);
            });
        }

        @JavascriptInterface
        public double nextReminder() {
            return Reminders.nextTime(MainActivity.this);
        }
    }
}

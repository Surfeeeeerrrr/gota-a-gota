package app.gotaagota;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Recebe o alarme: mostra o aviso (se você não bebeu água há pouco) e agenda o próximo. */
public class ReminderReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent intent) {
        String action = intent.getAction();
        if (Reminders.ACTION_SNOOZE.equals(action)) {
            Reminders.dismiss(c);
            Reminders.snooze(c, 10);
            return;
        }
        if (!Reminders.prefs(c).getBoolean("on", false)) return;
        long lastDrink = Reminders.prefs(c).getLong("lastDrink", 0);
        if (System.currentTimeMillis() - lastDrink > 10 * 60000L) {
            Reminders.show(c, false);
        }
        Reminders.schedule(c);
    }
}
